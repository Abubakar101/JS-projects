const bd = document.querySelector('.bd');
  const items     = bd.querySelectorAll('li');
    const questions = bd.querySelectorAll('.question');
    
function togglebd() {
      const thisItem = this.parentNode;
      
  items.forEach(item => {
        if (thisItem == item) {
          thisItem.classList.toggle('open');   
          return;
        }
        item.classList.remove('open');
      });         
    }


questions.forEach(question => question.addEventListener('click', togglebd)
);